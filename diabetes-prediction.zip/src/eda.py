
import seaborn as sns
import matplotlib.pyplot as plt

def plot_outcome_distribution(data):
    sns.countplot(x='Outcome', data=data)
    plt.title("Diabetes Outcome Distribution")
    plt.show()

def plot_pairplot(data):
    sns.pairplot(data, hue="Outcome", diag_kind='kde')
    plt.show()

def plot_correlation_heatmap(data):
    plt.figure(figsize=(10, 6))
    sns.heatmap(data.corr(), annot=True, cmap="coolwarm")
    plt.title("Correlation Heatmap")
    plt.show()

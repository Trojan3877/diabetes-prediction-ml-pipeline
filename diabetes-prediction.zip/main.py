
import yaml
from src.data_preprocessing import load_data, preprocess_data
from src.eda import plot_outcome_distribution, plot_pairplot, plot_correlation_heatmap
from src.model_training import train_model
from src.evaluation import evaluate_model

# Load config
with open("config/config.yaml", "r") as file:
    config = yaml.safe_load(file)

# Step 1: Load data
data = load_data(config["data"]["raw_data_path"])
print(data.head())

# Step 2: EDA
plot_outcome_distribution(data)
plot_pairplot(data)
plot_correlation_heatmap(data)

# Step 3: Preprocessing
X_train, X_test, y_train, y_test = preprocess_data(
    data,
    target_column="Outcome",
    test_size=config["model"]["test_size"],
    random_state=config["model"]["random_state"]
)

# Step 4: Train Model
model = train_model(X_train, y_train, random_state=config["model"]["random_state"])

# Step 5: Evaluate Model
evaluate_model(model, X_test, y_test)
